# EkoParty 2020 issue tracker

This is the internal ekoparty issue tracker for the 2020 edition.

Please file any conference issues here for staff triage.

Note: this repository uses github actions:

https://docs.github.com/en/actions

Also, congrats for solving Stage 2!

EKO{1ca688c86b0548d8f26675d85dd77d73c573ebb6}
