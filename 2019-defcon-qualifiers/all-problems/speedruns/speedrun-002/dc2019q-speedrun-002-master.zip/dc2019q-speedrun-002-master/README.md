# speedrun-002

[![Build Status](https://travis-ci.com/o-o-overflow/dc2019q-speedrun-002.svg?token=6XM5nywRvLrMFwxAsXj3&branch=master)](https://travis-ci.com/o-o-overflow/dc2019q-speedrun-002)

Second speedrun challenge. Simple stack-based buffer overflow, NX, no-pie, ASLR, dynamically linked binary. 
 
