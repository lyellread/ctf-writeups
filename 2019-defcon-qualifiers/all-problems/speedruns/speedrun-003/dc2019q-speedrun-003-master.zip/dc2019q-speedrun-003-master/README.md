# speedrun-003

[![Build Status](https://travis-ci.com/o-o-overflow/dc2019q-speedrun-003.svg?token=6XM5nywRvLrMFwxAsXj3&branch=master)](https://travis-ci.com/o-o-overflow/dc2019q-speedrun-003)

This speedrun is a shellcoding challenge, 30 bytes total, no null, no 0x90, xor(shellcode[:15]) == xor(shellcode[15:]).


 
