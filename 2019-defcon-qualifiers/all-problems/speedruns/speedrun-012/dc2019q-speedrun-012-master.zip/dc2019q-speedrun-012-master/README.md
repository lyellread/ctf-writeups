# speedrun-012

[![Build Status](https://travis-ci.com/o-o-overflow/dc2019q-speedrun-012.svg?token=6XM5nywRvLrMFwxAsXj3&branch=master)](https://travis-ci.com/o-o-overflow/dc2019q-speedrun-012)

JS engine exploitation (with a read/write primitive)
 
