# speedrun-006

[![Build Status](https://travis-ci.com/o-o-overflow/dc2019q-speedrun-006.svg?token=6XM5nywRvLrMFwxAsXj3&branch=master)](https://travis-ci.com/o-o-overflow/dc2019q-speedrun-006)

No-null shellcoding challenge with small byte arrays spread throughout.



 
