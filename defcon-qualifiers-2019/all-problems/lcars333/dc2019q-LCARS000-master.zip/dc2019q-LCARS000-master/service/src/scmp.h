#ifndef _SCMP_H
#define _SCMP_H

#include "common.h"

int load_policy(enum app_ctx ctx);

#endif
