# speedrun-004

[![Build Status](https://travis-ci.com/o-o-overflow/dc2019q-speedrun-004.svg?token=6XM5nywRvLrMFwxAsXj3&branch=master)](https://travis-ci.com/o-o-overflow/dc2019q-speedrun-004)

One-byte buffer overflow, NX, no-pie, ASLR, statically compiled binary.

 
