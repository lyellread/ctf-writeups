# speedrun-007

[![Build Status](https://travis-ci.com/o-o-overflow/dc2019q-speedrun-007.svg?token=6XM5nywRvLrMFwxAsXj3&branch=master)](https://travis-ci.com/o-o-overflow/dc2019q-speedrun-007)

Relative write, NX, pie, ASLR, dynamically linked, no canaries


 
