# speedrun-0001

[![Build Status](https://travis-ci.com/o-o-overflow/dc2019q-speedrun-001.svg?token=6XM5nywRvLrMFwxAsXj3&branch=master)](https://travis-ci.com/o-o-overflow/dc2019q-speedrun-001)

First speedrun challenge. Simple stack-based buffer overflow, NX, no-pie, ASLR, statically compiled binary. 
