# speedrun-008

[![Build Status](https://travis-ci.com/o-o-overflow/dc2019q-speedrun-008.svg?token=6XM5nywRvLrMFwxAsXj3&branch=master)](https://travis-ci.com/o-o-overflow/dc2019q-speedrun-008)


BROP-style buffer overflow, NX, no pie, ASLR, statically linked, static canary (derived from flag)
 
