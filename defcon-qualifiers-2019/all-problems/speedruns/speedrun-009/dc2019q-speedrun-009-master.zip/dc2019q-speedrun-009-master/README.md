# speedrun-009

[![Build Status](https://travis-ci.com/o-o-overflow/dc2019q-speedrun-009.svg?token=6XM5nywRvLrMFwxAsXj3&branch=master)](https://travis-ci.com/o-o-overflow/dc2019q-speedrun-009)

Format string (without %n) to leak address and canary, buffer overflow, NX, pie, ASLR, dynamically linked
 
