# speedrun-005

[![Build Status](https://travis-ci.com/o-o-overflow/dc2019q-speedrun-005.svg?token=6XM5nywRvLrMFwxAsXj3&branch=master)](https://travis-ci.com/o-o-overflow/dc2019q-speedrun-005)

Classic format string, NX, no pie, ASLR.
 
