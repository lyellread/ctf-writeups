#! /bin/sh

while true; do
    rm -f /tmp/*log
    /election_coin
done
