#! /bin/bash

python /app/test.py "$1" "$2"
